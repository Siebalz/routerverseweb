<?php $__env->startSection('title', 'Edit Produk'); ?>

<?php $__env->startPush('styles'); ?>
.form-panel {
    background: #fff;
    border-radius: 16px;
    padding: 26px;
    box-shadow: 0 2px 10px rgba(20, 20, 50, 0.04);
    max-width: 900px;
}

.btn-brand-submit {
    background: var(--brand);
    border: none;
    color: #fff;
    font-weight: 600;
    border-radius: 10px;
    padding: 10px 22px;
}

.btn-brand-submit:hover { background: var(--brand-dark); color: #fff; }
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <div class="d-flex align-items-center gap-2 mb-3">
        <a href="<?php echo e(route('products.index')); ?>" class="text-decoration-none text-muted"><i class="bi bi-arrow-left fs-5"></i></a>
        <h4 class="fw-bold mb-0">Edit Produk</h4>
    </div>

    <div class="form-panel">
        <form method="POST" action="<?php echo e(route('products.update', $product)); ?>" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo $__env->make('products._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Projek\WEB\routerverse-mainttt\routerverse-main\resources\views/products/edit.blade.php ENDPATH**/ ?>