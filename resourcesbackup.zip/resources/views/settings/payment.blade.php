@extends('layouts.dashboard')

@section('title', 'Setting Pembayaran')

@push('styles')
.settings-panel {
    background: #fff;
    border-radius: 16px;
    padding: 26px;
    box-shadow: 0 2px 10px rgba(20, 20, 50, 0.05);
    max-width: 640px;
}

.qris-preview {
    width: 220px;
    border-radius: 12px;
    border: 1px solid #ededf3;
    padding: 10px;
    background: #fff;
}

.settings-divider {
    border-top: 1px dashed #ededf3;
    margin: 28px 0 22px;
}

.method-label {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    font-weight: 700;
    margin-bottom: 14px;
}

.method-label .bank-pill {
    background: #eef0ff;
    color: #3b46f2;
    font-size: 0.72rem;
    font-weight: 700;
    padding: 3px 10px;
    border-radius: 999px;
}
@endpush

@section('content')

    <h4 class="fw-bold mb-1">Setting Pembayaran</h4>
    <p class="text-muted mb-4">Atur QRIS &amp; Transfer Bank BCA di sini — otomatis muncul di halaman produk &amp; pemesanan layanan, tidak perlu ubah kode.</p>

    <div class="settings-panel">
        <form method="POST" action="{{ route('settings.payment.update') }}" enctype="multipart/form-data">
            @csrf

            {{-- ══ QRIS ══ --}}
            <div class="method-label"><i class="bi bi-qr-code"></i> QRIS <span class="bank-pill">Scan &amp; Bayar</span></div>

            @if ($setting->qris_image)
                <div class="mb-3">
                    <label class="form-label fw-semibold small text-muted">QRIS Saat Ini</label><br>
                    <img src="{{ asset('storage/'.$setting->qris_image) }}" class="qris-preview" alt="QRIS">
                </div>
            @endif

            <div class="mb-3">
                <label class="form-label fw-semibold">Upload Gambar QRIS {{ $setting->qris_image ? '(ganti)' : '' }}</label>
                <input type="file" name="qris_image" accept="image/*" class="form-control">
                <div class="form-text">Upload gambar QR code statis dari bank/e-wallet Anda. Format JPG/PNG, maksimal 2MB.</div>
            </div>

            <div class="settings-divider"></div>

            {{-- ══ Transfer Bank BCA ══ --}}
            <div class="method-label"><i class="bi bi-bank"></i> Transfer Bank BCA <span class="bank-pill">Manual Transfer</span></div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-semibold">Nomor Rekening BCA</label>
                    <input type="text" name="bca_account_number" class="form-control"
                           placeholder="Contoh: 1234567890"
                           value="{{ old('bca_account_number', $setting->bca_account_number) }}">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-semibold">Nama Pemilik Rekening</label>
                    <input type="text" name="bca_account_name" class="form-control"
                           placeholder="Contoh: John Doe"
                           value="{{ old('bca_account_name', $setting->bca_account_name) }}">
                </div>
            </div>
            <div class="form-text mb-3" style="margin-top:-10px;">Kosongkan nomor rekening jika belum ingin menampilkan opsi Transfer BCA ke pembeli.</div>

            <div class="settings-divider"></div>

            <div class="mb-3">
                <label class="form-label fw-semibold">Catatan / Instruksi Pembayaran</label>
                <textarea name="notes" rows="4" class="form-control" placeholder="Contoh: Scan QRIS / transfer ke rekening BCA di atas sesuai nominal pesanan, lalu kirim bukti transfer ke WhatsApp kami untuk konfirmasi.">{{ old('notes', $setting->notes) }}</textarea>
                <div class="form-text">Catatan ini akan tampil untuk kedua metode pembayaran (QRIS &amp; Transfer BCA).</div>
            </div>

            <div class="form-check form-switch mb-4">
                <input class="form-check-input" type="checkbox" id="is_active" name="is_active" value="1"
                    {{ old('is_active', $setting->is_active) ? 'checked' : '' }}>
                <label class="form-check-label fw-semibold" for="is_active">Tampilkan QRIS &amp; Transfer BCA ke pembeli</label>
            </div>

            <button type="submit" class="btn btn-primary px-4">Simpan</button>
        </form>
    </div>

@endsection
